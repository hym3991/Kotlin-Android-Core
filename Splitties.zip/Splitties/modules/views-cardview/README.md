# Views CardView

*CardView extension of [Views](../views)*

## Content

`contentPadding` allows to set the padding of the content of a `CardView`
using property syntax.

This is all this split provides at the moment.

## Download

```groovy
implementation("com.louiscad.splitties:splitties-views-cardview:$splitties_version")
```
